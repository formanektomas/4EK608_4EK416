###################################
# 4EK608 - Advanced Econometrics  #
# R packages required for Block 5 #
###################################
#
#
install.packages("lmtest", dependencies = T)
#
install.packages("forecast", dependencies = T)
#
install.packages(c("tseries", "tsDyn"), dependencies = T)
#
install.packages("urca", dependencies = T)
# 
install.packages("zoo", dependencies = T) 
#
install.packages("vars", dependencies = T)
#
install.packages('ggplot2', dependencies = T)
