#### Repetition of basic estimation using R #### 
#
# 
# 
# 
#
#
### Example 4.9: Based on Wooldridge: Introductory econometrics, 
#    
#   Parents' education in a birth-weight equation (extended example)
#   
#
# Data
rm(list=ls())
bwght.df <- read.csv('bwght.csv') # Read the data

#
# Model data:
#
# bwght    - birth weight, ounces
# cigs     - cigarettes smoked per day while pregnant
# parity   - birth order of child
# faminc   - 1988 family income, $1000s
# fatheduc - father's years of education
# motheduc - mother's years of education
# packs    - packs smoked per day while pregnant (==cigs/20)
# bwghtlbs - birth weight, pounds (1 pound = 16 ounces)
#
#
#
# Basic data plots
boxplot(bwght.df$bwght ~ bwght.df$parity)
plot(bwght.df$bwght ~ bwght.df$cigs)
#
# Estimation of the model by OLS
lm.1 <- lm(bwght ~ cigs + parity + faminc + motheduc + fatheduc,data=bwght.df)
summary(lm.1)
#
# In order to test the joint significance of parental education, we need to
# estimate an auxiliary model with "motheduc" and "fatheduc" removed.
# 
# Note: For comparsion purposes, both lm.1 and lm.2 need to be estimated
# using identical datasets (i.e. for lm.2, we ommit rows with NA values
# in fatheduc or motheduc)
lm.2 <- lm(bwght ~ cigs + parity + faminc, 
           data=bwght.df[is.na(bwght.df$motheduc)!=TRUE & is.na(bwght.df$fatheduc)!=TRUE,])
summary(lm.2)
# 
# Tests for joint insignificance of "fatheduc" and "motheduc" in lm.1 regression:
#
# 1) Anova / F test for linear restrictions:
anova(lm.1,lm.2)
#
# 2) Wald test (F/Chi-square)
require(lmtest) # install.packages("lmtest")
?waldtest
waldtest(lm.2, lm.1, test = "F")
waldtest(lm.2, lm.1, test = "Chisq")
#
#
#
# Heteroskedasticity test for lm.2
?bptest
bptest(lm.2) # H0: no heteroskedasticity (not rejected)
#
#
#
# Test for normality of residuals
require(tseries) # install.packages("tseries")
?jarque.bera.test
jarque.bera.test(lm.2$residuals) 
#
# Let's estimate the lm.2 specification with log(bwght)
lm.3 <- lm(log(bwght) ~ cigs + parity + faminc, 
           data=bwght.df[is.na(bwght.df$motheduc)!=TRUE & is.na(bwght.df$fatheduc)!=TRUE,])
#
# Compare interpretation of coefficients:
summary(lm.2) # bwght as the dependent variable
summary(lm.3) # log(bwght) as the dependent variable
#
#
#
# RESET test
?resettest
resettest(lm.2, power=3, type="fitted")
resettest(lm.3, power=3, type="fitted")
#
#
#
# Forecasting from an estimated model
#
?predict()
#
#
head(predict(lm.2),10)
#
## Interval predictions
#
head(predict(lm.2, interval = "prediction"), 10)
# we predict "individual" birth weights, coefficient estimation uncertainty
# and the effect of random errors is taken into account
# when calculating intervals
#
head(predict(lm.2, interval = "confidence"), 10)
# Reflects the uncertainty (confidence interval) related to
# "average" predictions - as if we had many datasets to estimate
# the LRM and make predictions. Here, we ignore the variance of
# residuals.
# 
# "confidence" intervals are usually narrower than "prediction" intervals.
#