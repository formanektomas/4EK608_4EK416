#### Repetition of effects of inflation and deficit on interest rates #### 
#
# 
# 
# 
#
#
### Example 11.6 : Based on Wooldridge: Introductory econometrics, 
#    
#   Fertility equation
#   
#
# Data
rm(list=ls())
fertil3 <- read.csv('fertil3.csv') # Read the data

#
# Model data:
# Annual TS, 1913 - 1984
#
# gfr      - births per 1000 women 15-44
# pe       - real value of personal exemption in USD
# ww2      - binary, =1 for 1941-1945
# pill     - binary, =1 if year >= 1963
#
#
#
# Basic data plots
plot(fertil3$gfr ~ fertil3$year) # points
plot(fertil3$gfr ~ fertil3$year, type="l") # line
#
class(fertil3)
# 
fertil3.ts <- ts(fertil3, start = 1913, frequency = 1)
# Use frequency=4 for quarterly and frequency=12 for monthly data
class(fertil3.ts)
head(fertil3.ts)
#
# Assuming our data meet classical assumptions for time series
# (stationarity....)
#
# Estimation of the model by OLS
model1 <- lm(gfr ~ pe, data = fertil3.ts)
summary(model1)
#
# The model may be improved by introducing lagged values of pe 
# .. (individuals may react to tax incentives with some delay)
#
# We shall create lag 1 and lag 2 for pe:
# .. the dataframe already contains lagged values, 
# .. we ignore those for the moment.  
pe_1 <- lag(fertil3.ts[,"pe"], -1) # Note the "-1" syntax for t-1...
pe_2 <- lag(fertil3.ts[,"pe"], -2) # Note the "-2" syntax for t-2...
#
# !! Very important step for ts variables !!
# Now we use ts.union() for all data series entering our regression
newData <- ts.union(fertil3.ts[ ,"gfr"], fertil3.ts[ ,"pe"], pe_1, pe_2, 
                    fertil3.ts[ ,"pill"], fertil3.ts[ ,"ww2"])
colnames(newData)
colnames(newData) <- c("gfr", "pe", "pe_1", "pe_2", "pill", "ww2")
#
model2 <- lm(gfr ~ pe + pe_1 + pe_2, data = newData)
summary(model2)
#
model3 <- lm(gfr ~ pe + pe_1 + pe_2 + pill + ww2, data = newData)
summary(model3)
#
# Are the gfr and pe series stationary?
# .. the following tests are for illustration purposes only,
# .. this topic shall be discussed in detail later in the course
require("forecast") #install.packages("forecast")
?ndiffs 
ndiffs(fertil3.ts[, "gfr"], alpha=0.05, test="kpss")
ndiffs(fertil3.ts[, "pe"], alpha=0.05, test="kpss")
#
#
# We shall use first differences of "gfr" and "pe" in the model2
#
#
model2.d <- lm(diff(gfr) ~ diff(pe) + diff(pe_1) + diff(pe_2), data = newData)
summary(model2.d)
summary(model2) # for comparison
#
# 
# Now, we shall try to expand model2.d by introducing
# - trend (variable "time")
# - ww2 and pill variables.
#
# First, we need to prepare the dataset:
d.gfr <- diff(fertil3.ts[,"gfr"])
d.pe <-  diff(fertil3.ts[,"pe"])
d.pe_1 <-  diff(fertil3.ts[,"pe_1"])
d.pe_2 <-  diff(fertil3.ts[,"pe_2"])
newData2 <- ts.union(d.gfr, d.pe, d.pe_1, d.pe_2, 
                     fertil3.ts[ ,"pill"], fertil3.ts[ ,"ww2"], fertil3.ts[ ,"time"])
head(newData2)
colnames(newData2) <- c("d.gfr", "d.pe", "d.pe_1", "d.pe_2", "pill", "ww2", "time")
#
# Adding time trend to model2.d:
model4 <- lm(d.gfr ~ d.pe + d.pe_1 + d.pe_2 + time, data = newData2)
summary(model4)
#
# Adding ww2 and pill to model2.d
model5 <- lm(d.gfr ~ d.pe + d.pe_1 + d.pe_2 + ww2 + pill, data = newData2)
summary(model5)
#
## Assignment 1
## using the "anova" F-test, verify the joint significance of ww2 and pill
## and interpret the results.
#  ..Hint: model2.d object may not be used, you need to re-estimate using newData2
#
#
#
#
# Estimation of the LRP (Long-run propensity) of pe from model3:
summary(model3) # repeat the results from model3
# LRP estimation
model6 <- lm(gfr ~ pe + I(pe_1-pe) + I(pe_2-pe) + pill + ww2, data = newData)
summary(model6)
#
#
#