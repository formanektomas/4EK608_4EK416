##################################
# 4EK608 - Advanced Econometrics #
# R packages required for Week 1 #
##################################
#
install.packages("forecast", dependencies = T)
#
install.packages("lmtest", dependencies = T)
#
install.packages("sandwich", dependencies = T)
#
install.packages("tseries", dependencies = T)
#
install.packages("prais", dependencies = T)
#
install.packages("orcutt", dependencies = T)
#
install.packages("ggplot2", dependencies = T)
#
install.packages("zoo", dependencies = T)
#
install.packages("car", dependencies = T)
#
install.packages("margins", dependencies = T)
#
install.packages("RcmdrMisc", dependencies = T)
#