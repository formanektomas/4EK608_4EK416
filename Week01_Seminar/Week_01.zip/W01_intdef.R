#### Repetition of effects of inflation and deficit on interest rates #### 
#
# 
# 
# 
#
#
### Example 10.2: Based on Wooldridge: Introductory econometrics, 
#    
#   Effects of inflation and deficit on interest rates
#   
#
# Data
rm(list=ls())
intdef <- read.csv('intdef.csv') # Read the data

#
# Model data:
# Annual TS, 1948 - 2003
#
# i3       - 3 month T bill rate
# inf      - CPI inflation rate
# def      - deficit as % of GDP
#
#
#
# Basic data plots
plot(intdef[ , c(2,3,6)])
plot(intdef$i3 ~ intdef$inf)
#
class(intdef)
# 
intdef.ts <- ts(intdef, start = 1948, frequency = 1)
# Use frequency=4 for quarterly and frequency=12 for monthly data
class(intdef.ts)
head(intdef.ts)
#
# Estimation of the model by OLS
lm.10.15<-lm(i3 ~ inf + def, data=intdef)
summary(lm.10.15)
#
# Testing for AR(1)
require(lmtest) # install.packages("lmtest")
bgtest(lm.10.15, order=1) # H0: residuals are not autocorrelated
#
#
# Estimating the ar(1)  rho-coefficient using auxiliary OLS regression:
resid.current <- lm.10.15$residuals # not a "ts", but a numeric vector! 
resid.current <- ts(resid.current, start = 1948, frequency = 1)
resid.lag.1 <- lag(resid.current, -1) # Note the "-1" syntax for t-1...
# Now we use ts.union() for all data series entering our regression
newData <- ts.union(resid.current, resid.lag.1)
summary(lm(resid.current ~ -1 + resid.lag.1, data = newData)) # "-1" excludes the intercept.
#
#
# Testing for AR(2) and higher orders
bgtest(lm.10.15, order=2) # etc.
#
#
# 
## Assignment 1
## Use auxiliary OLS regression to estimate the parameters of an AR(2)
## process, for the random elements of model lm.10.15.
## Use "resid.current" residuals from line 49 as your dependent variable.
#
#
#
#
### Example 12.6: Based on Wooldridge: Introductory econometrics, 
#    
#   Differencing the interest rate equation
#   
#
lm.12.39 <-lm(diff(i3) ~ diff(inf) + diff(def), data=intdef)
summary(lm.12.39)
bgtest(lm.12.39, order=1)
#
# The coefficients in lm.12.39 differ significantly from lm.10.15...
# Correlation between i3(t) and i3(t-1)
#
i3_1 <- lag(intdef.ts[, "i3"], -1)
newData2 <- ts.union(i3_1, intdef.ts[, "i3"])
# Correlation matrix
cor(newData2[complete.cases(newData2) == T, ])
#
#
#