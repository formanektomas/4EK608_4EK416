#### Repetition: R^2 for a trending dependent variable #### 
#
# 
# 
# 
#
#
### Example 10.7: Housing investment and prices, 
#    
#   
#   
#
# Data
rm(list=ls())
hseinv <- read.csv('hseinv.csv') # Read the data

#
# Model data:
# Annual TS, 1947 - 1988
#
# invpc    - per capita invest., 
#            real housing investment in millions USD / population
# price    - housing price index, 1982 = 1
# time     - time trend
#
#
#
# Basic data plots
plot(hseinv$invpc ~ hseinv$price)
plot(hseinv$invpc ~ hseinv$time, type = "l")
plot(hseinv$price ~ hseinv$time, type = "l")
#
#
class(hseinv)
# 
hseinv.ts <- ts(hseinv, start = 1947, frequency = 1)
# Use frequency=4 for quarterly and frequency=12 for monthly data
#
# Estimation of the model by OLS
lm.10.32 <- lm( log(invpc) ~ log(price), data=hseinv.ts)
summary(lm.10.32)
require(lmtest) # install.packages("lmtest")
bgtest(lm.10.32, order=1) # H0: residuals are not autocorrelated
# Neglected nonstationarity in series results in autocorrelation,
# st.errs, t-ratios, F-test and R^2 estimates are unreliable
#
#
# Explicit inclusion of time-trend into the equation
lm.10.33 <- lm( log(invpc) ~ log(price) + time, data=hseinv.ts)
summary(lm.10.33)
# 
## Assignment 1
## Test lm.10.33 for AR(1) and for autocorrelation up to second order, i.e. AR(2).
#
#
# De-trending of the dependent variable (Example 10.10)
#
# We keep time-trend in the equation, as we assume log(price) is trending
dtr.linvpc <- lm( log(invpc) ~ time, data=hseinv.ts)$resid # de-trended series
model.10.10 <- (lm(dtr.linvpc ~ log(price) + time, data=hseinv.ts ))
summary(model.10.10)
#
## Assignment 2
## Interpret the value of Adjusted R-squared in model.10.10
#
#
#
#
#