#### Repetition of AR(1) model, efficient market hypothesis, 
#### ARCH in stock returns #### 
#
# 
# For illustration purposes, this example does NOT involve transformation 
# of data to TS.
#
# .. All regressions may be performed and lagged variables may be produced "manually", 
# .. but some commands (lag, diff) may not be used properly..
# 
#
#
### Example 11.4: Efficient markets hypothesis
#    
#   
# ..Information observed prior to time (t) should not help to
#   predict the return during week (t).
#
# Data
rm(list=ls())
nyse <- read.csv('nyse.csv') # Read the data

#
# Model data:
# Weekly observations, 7 January 1976 - 29 March 1989 
#
# return   - 100*(p(t)-p(t-1) / p(t-1))
# return_1 - return(t-1)
# 
#
#
#
# Basic data plots
plot(nyse$return ~ nyse$return_1, type = "p" )
#
#
# Estimation of the AR(1) model
lm.11.16 <- lm( return ~ return_1, data=nyse)
summary(lm.11.16) # 
#
# Note: "return" is an R command and it is not a good
#       idea to use it as a variable name in R, although
#       it does not cause any problems in our simple example...
search() # ?search
#
#
#
#
#
### Example 12.8: Heteroskedasticity and the efficient markets hypothesis
#    
#
lm.12.8<-lm(return ~ return_1, data = nyse) # same as lm.11.16
summary(lm.12.8)
#
res <- lm.12.8$residuals^2
lm.12.8.bp <- lm(res ~ return_1,data=na.omit(nyse))
summary(lm.12.8.bp)
# this is the equation for the Breusch-Pagan heteroskedasticity test:
require(lmtest) # install.packages("lmtest")
bptest(lm.12.8, studentize = F) # results based on chisq statistics, not the F-statistics.
#
#
#
#
#
### Example 12.9: ARCH in stock returns
#    
#
u <- lm.12.8$residuals
u_1 <- c(NA,u[-length(u)])
usq <- lm.12.8$residuals^2
usq_1 <- c(NA,usq[-length(usq)])
# Conditional heteroskedasticity ARCH(1). Shall be discussed later in the course.
arch <- lm(usq ~ usq_1)
summary(arch)
# rho from equation lm.12.8
lm.12.9.3<-lm(u ~ u_1)
summary(lm.12.9.3)
#
#
#
#
#
#