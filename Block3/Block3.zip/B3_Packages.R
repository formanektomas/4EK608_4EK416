###################################
# 4EK608 - Advanced Econometrics  #
# R packages required for Block 3 #
###################################
#
#
install.packages(c('ggplot2','AER','lmtest','car','dplyr','zoo'), dependencies = T)
#
install.packages(c('plm','systemfit','broom','psych'), dependencies = T)
#