###################################
# 4EK608 - Advanced Econometrics  #
# R packages required for Block 1 #
###################################
#
#
install.packages(c('ggplot2','AER','lmtest','car','forecast'), dependencies = T)
#
install.packages(c('boot','lattice','ISLR','RcmdrMisc'), dependencies = T)
#
install.packages(c('gmm','quantreg','sandwich','margins'), dependencies = T)