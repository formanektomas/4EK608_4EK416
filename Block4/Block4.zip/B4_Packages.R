###################################
# 4EK608 - Advanced Econometrics  #
# R packages required for Block 4 #
###################################
#
install.packages('AER', dependencies = T)
#
install.packages("systemfit", dependencies = T)
#
install.packages('ggplot2', dependencies = T)
#
install.packages('lattice', dependencies = T)
#
install.packages('lmtest', dependencies = T)
#
install.packages('sandwich', dependencies = T)
#
install.packages('ISLR', dependencies = T)
#
install.packages('car', dependencies = T)